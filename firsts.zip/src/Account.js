import './Account.css';

function Account(prop){
    return(
        <div className='profile'>
            <img src={prop.img} className='i' alt='pic1'/>
            <h1>{prop.name}</h1>
            <h3>{prop.exp}</h3>
            <p>{prop.desc}</p>
            <h3>{prop.salary}</h3>
        </div>
    );
}

export default Account;