import './Signing.css';

function Signing(){

    function submit(){
        
        var user = document.getElementById("suser").value;
        var pass = document.getElementById("spass").value;
        var cpass = document.getElementById("scpass").value;
        
        if(pass !== cpass){
            alert("Password not match");
            return;
        }

        alert("Signup Successful");
    }


    return (
        <div className="container">
            <h1>Sign Up</h1>
            <div className="form-box">
                <label>Username: </label>
                <input type="text" id="suser" placeholder="Username"  required/><br />

                <label>Password: </label>
                <input type="password" id="spass" placeholder="Password" /><br />

                <label>Confirm Password: </label>
                <input type="password" id="scpass" placeholder="Confirm Password" /><br />

                <button onClick={submit}>Sign Up</button>
            </div>
        </div>
    );
}

export default Signing;