import './App.css';

import Account from './Account';

function App() {
  
  return (
    <div>
      <Account img="https://i.pravatar.cc/150?img=3" name="Sanket" exp="Experince: 3.4 Years" desc="Hello My name is Sanket" salary="Current Salary: 10000"/>

    </div>
    

  );
}

export default App;
