function Login(){

    function login(){
        
        var uNames = ["Sanket", "Uttam", "Gaurav"];
        var uPass = ["1234", "1122", "2222"] ;

        var user = document.getElementById("user").value;
        var pass = document.getElementById("pass").value;

        for(var i =0; i<uNames.length; i++){
            if(uNames[i] === user && uPass[i] === pass){
                alert(`Successfully Login.. Username is ${user} and Password is ${pass}`);
                return;
            }
        }
        alert(`Login Failed...`);

    }
    



    return (
        <div className="container">
            <h1>Login</h1>
            <div className="form-box">
                <label>Username: </label>
                <input type="text" id="user" placeholder="Username"></input><br></br>

                <label>Password: </label>
                <input type="password" id="pass" placeholder="Passwoerd"></input><br></br>

                <button onClick={login}>Login</button>
            </div>
        </div>
        
    );
}

export default Login;