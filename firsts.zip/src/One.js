import { useState } from "react";

function One(){
    var [name, setName] = useState("Sanket");
    var [num, setNum] = useState(10);
    var [val, setval] = useState(true);
    var [value, setValue] = useState(1);



    var [color, setColor] = useState("green");

    var colors = ["green", "red", "yellow", "black","orange","pink","blue"];
    var [index, setIndex] = useState(0);

    var [box, setBox] = useState({height:"200px",width:"200px",color:"green", backgroundColor:"yellow"});

    var changeCss = () =>{
        setBox({height:"200px",width:"200px",color:"blue", backgroundColor:"red", borderRadius:"50%", textAlign:"center"});
    }



    var change = () =>{
        setName("Gaurav");
    }

    var change2 = () =>{
        setNum(num+10);
    }

    var change3 = () =>{
        setval(!val);
    }

    var change4 = () =>{
        setValue(value*2);
    }

    var change5 = () =>{
        var change = ["green", "red", "yellow", "black","orange","pink","blue"];
        var random = Math.floor(Math.random() * change.length);
        setColor(change[random]);
    }

    var change6 = ()=>{
        setIndex(index + 1);
    }

    return (
        <div>
            <h1>Hello From One{name}</h1>
            <button onClick={change}>Change</button>
            <h2>{num}</h2>
            <button onClick={change2}>Change Number</button>
            <h2>{val ? "True" : "False"}</h2>
            <button onClick={change3}>Change Boolean</button>
            <h2>{value}</h2>
            <button onClick={change4}>Change Number</button>
            <h2 style={{height:"200px", width:"400px", backgroundColor:color}}>Hello</h2>
            <button onClick={change5}>Change Color</button>

            <h2 style={{height:"200px", width:"400px", backgroundColor:colors[index]}}>Hello</h2>
            <button onClick={change6}>Change Color</button>

            <h2 style={box}>Hello</h2>
            <button onClick={changeCss}>Change Color</button>
           
        </div>
    )
};

export default One;