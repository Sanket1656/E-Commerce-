import './Profile.css'

function Profile(){
    var profiles = [{
        pid:1,
        pimage:"https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
        pname: "Sanket",
        pabout: "This is Smart boy",
        pexperiance: "5year"
    },
    {   
        pid:2,
        pimage:"https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
        pname: "Kevin",
        pabout: "This is Smart boy",
        pexperiance: "5year"
    },
    {
        pid:3,
        pimage:"https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
        pname: "Uttam",
        pabout: "This is Smart boy",
        pexperiance: "5year"
    },
    {
        pid:4,
        pimage:"https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
        pname: "Gaurav",
        pabout: "This is Smart boy",
        pexperiance: "5year"
    },
    {
        pid:5,
        pimage:"https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
        pname: "Anurag",
        pabout: "This is Smart boy",
        pexperiance: "5year"
    },]
    return (
        <div className="profile-container">
            <h1 className="profile-title">Hello From Profile</h1>

            <div className="cards-wrapper">
                <div className="cards-row">
                    {profiles.map((prof) => (
                        <div className="cards" key={prof.pid}>
                            <img src={prof.pimage} alt="profile" className="i" />
                            <h1>{prof.pname}</h1>
                            <p>{prof.pabout}</p>
                            <span>{prof.pexperiance}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
};  

export default Profile;