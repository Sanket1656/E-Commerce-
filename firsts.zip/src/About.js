import './About.css';

function About(){
    var products = [
        {
            pid:1,
            pname:"Pen",
            pdesc:"It is Smart Pen",
            pimage:"img1.jpg"
        },
        {
            pid:2,
            pname:"Pen",
            pdesc:"It is Smart Pen",
            pimage:"img1.jpg"
        },
        {
            pid:3,
            pname:"Pen",
            pdesc:"It is Smart Pen",
            pimage:"img1.jpg"
        },
        {
            pid:4,
            pname:"Pen",
            pdesc:"It is Smart Pen",
            pimage:"img1.jpg"
        },
        {
            pid:5,
            pname:"Pen",
            pdesc:"It is Smart Pen",
            pimage:"img1.jpg"
        },

    ];

    return (
        <div>
            <h1>Hello from about</h1>
            <div className='card'>
                {products.map((pro)=>{return(
                    <div>
                        <img src={pro.pimage} className='i'/>
                        <h1>{pro.pname}</h1>
                        <p>{pro.pdesc}</p>
                    </div>
                )})}
            </div>
        </div>
    )
}


export default About;